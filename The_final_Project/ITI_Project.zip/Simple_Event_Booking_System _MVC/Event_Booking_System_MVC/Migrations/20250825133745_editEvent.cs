﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Event_Booking_System_MVC.Migrations
{
    /// <inheritdoc />
    public partial class editEvent : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
